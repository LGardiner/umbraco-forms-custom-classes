﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;



namespace Web.Code.UmbracoForms
{
    public class CheckboxListExtended : Umbraco.Forms.Core.FieldType
    {
        [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
        public string CustomClass { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
        public string CustomProperty { get; set; }

        public CheckboxListExtended()
        {
            this.Id = new Guid("8e4462bd-f678-419f-8235-667bbe94220f");
            this.Name = "Multiple choice - extended";
            this.Description = "Renders a collection of checkboxes to select multiple answers with custom styles";
            this.Icon = "icon-bulleted-list";
            this.FieldTypeViewName = "FieldType.CheckBoxListExtended.cshtml";
            this.DataType = FieldDataType.String;
            this.SortOrder = -3;
            this.SupportsRegex = true;
            this.SupportsPreValues = true;
        }
    }
}