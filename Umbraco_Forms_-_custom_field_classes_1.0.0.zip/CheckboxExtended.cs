﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;



namespace Web.Code.UmbracoForms
{
    public class CheckboxExtended : Umbraco.Forms.Core.FieldType
    {
        [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
        public string CustomClass { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
        public string CustomProperty { get; set; }

        public CheckboxExtended()
        {
            this.Id = new Guid("8d2864bd-f678-469f-8235-420bbe94220f");
            this.Name = "Checkbox - extended";
            this.Description = "Render a checkbox with custom styles";
            this.Icon = "icon-checkbox";
            this.FieldTypeViewName = "Fieldtype.CheckboxExtended.cshtml";
            this.DataType = FieldDataType.Bit;
            this.SortOrder = -2;
            this.SupportsRegex = true;
        }
    }
}