﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;



namespace Web.Code.UmbracoForms
{
    public class DatePickerExtended : Umbraco.Forms.Core.FieldType
    {
        [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
        public string CustomClass { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
        public string CustomProperty { get; set; }

        public DatePickerExtended()
        {
            this.Id = new Guid("8d2864bd-f679-469f-8235-420bce942d0f");
            this.Name = "Date - extended";
            this.Description = "Render a date field with custom styles";
            this.FieldTypeViewName = "Fieldtype.DatePickerExtended.cshtml";
            this.Icon = "icon-calendar";
            this.DataType = FieldDataType.DateTime;
            this.SortOrder = -4;
            this.SupportsRegex = true;
        }
    }
}