﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;

public class FileUploadExtended : Umbraco.Forms.Core.FieldType
{
    [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
    public string CustomClass { get; set; }

    [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
    public string CustomProperty { get; set; }

    public FileUploadExtended()
    {
        Id = new Guid("00423d68-962e-458f-960e-a645d4a62000");
        Name = "File upload - extended";
        Description = "Renders an upload field, allowing files to be uploaded";
        Icon = "icon-download-alt ";
        SortOrder = -6;
        DataType = FieldDataType.String;
        FieldTypeViewName = "FieldType.FileUploadExtended.cshtml";
        SupportsRegex = true;
    }
}