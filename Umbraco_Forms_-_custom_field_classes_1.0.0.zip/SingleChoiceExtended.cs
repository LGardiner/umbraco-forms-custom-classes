﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;



namespace Web.Code.UmbracoForms
{
    public class SingleChoiceExtended : Umbraco.Forms.Core.FieldType
    {
        [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
        public string CustomClass { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
        public string CustomProperty { get; set; }

        public SingleChoiceExtended()
        {
            this.Id = new Guid("8e146254-f678-419f-8235-667bbe94220f");
            this.Name = "Single choice - extended";
            this.Description = "Renders a radio button list to enable a single choice answer with custom styles";
            this.Icon = "icon-target";
            this.FieldTypeViewName = "FieldType.RadioButtonListExtended.cshtml";
            this.DataType = FieldDataType.String;
            this.SortOrder = -7;
            this.SupportsRegex = true;
            this.SupportsPreValues = true;
        }
    }
}