﻿using Newtonsoft.Json;
using Service.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using Service;
using Umbraco.Forms.Core.Enums;
using Umbraco.Forms.Core.Models;
using Web.Code.Services;
using Web.Code.WebSupport;



namespace Web.Code.UmbracoForms
{
    public class TextExtended : Umbraco.Forms.Core.FieldType
    {
        [Umbraco.Forms.Core.Attributes.Setting("Headline", View = "TextField", Description="Enter a Headline")]
        public string Caption { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Body Text", View = "TextField", Description="Enter your copy text")]
        public string BodyText { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Class", View = "TextField", Description = "Enter your custom class (optional)")]
        public string CustomClass { get; set; }

        [Umbraco.Forms.Core.Attributes.Setting("Custom Property", View = "TextField", Description = "Enter your custom property (optional)")]
        public string CustomProperty { get; set; }

        public TextExtended()
        {
            this.Id = new Guid("8d2864bd-f678-469f-8235-66722294220f");
            this.Name = "Title and description - extended";
            this.Description = "This is used to enter some descriptive text";
            this.Icon = "icon-edit";
            this.FieldTypeViewName = "Fieldtype.TextExtended.cshtml";
            this.SortOrder = -10;
            this.SupportsRegex = true;
        }
    }
}